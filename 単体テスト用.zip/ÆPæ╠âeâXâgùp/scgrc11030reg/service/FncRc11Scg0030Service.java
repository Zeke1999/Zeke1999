/*******************************************************************************************
 * ALL RIGHTS RESERVED,COPYRIGHT (C) 2025,HITACHI,LTD. LICENSED MATERIAL OF HITACHI,LTD.
 *
 * 特許庁殿 刷新審判システム
 *
 *******************************************************************************************/
// ## AutomaticGeneration

package jp.go.jpo.cls.app.web.rc.scgrc11030reg.service;

import jp.go.jpo.cls.app.common.cmnbns0010.cmnbns0010150.service.CmnBns0010150Service;
import jp.go.jpo.cls.app.common.cmnbns0070.cmnbns0070010.dto.SyosiJouhouDto;
import jp.go.jpo.cls.app.common.cmnbns0070.cmnbns0070010.service.CmnBns0070010Service;
import jp.go.jpo.cls.app.common.cmnbns0120.cmnbns0120010.dto.TyuukanKirokuMeisyouJouhouDto;
import jp.go.jpo.cls.app.common.cmnbns0120.cmnbns0120010.service.CmnBns0120010Service;
import jp.go.jpo.cls.app.common.code.Cde0460;
import jp.go.jpo.cls.app.common.code.Cde0530;
import jp.go.jpo.cls.app.common.code.Cde0540;
import jp.go.jpo.cls.app.common.code.Cde0550;
import jp.go.jpo.cls.app.common.code.Cde0560;
import jp.go.jpo.cls.app.common.code.Cde0570;
import jp.go.jpo.cls.app.common.code.Cde0580;
import jp.go.jpo.cls.app.common.code.Cde0610;
import jp.go.jpo.cls.app.common.code.Cde1300;
import jp.go.jpo.cls.app.common.code.Cde1310;
import jp.go.jpo.cls.app.common.code.Cde2210;
import jp.go.jpo.cls.app.common.sif.dto.sifsa3dba0140jdu.UketukeBangouUketukeSyoruiKiziZikenDataKousinInDto;
import jp.go.jpo.cls.app.common.sif.dto.sifsa3dba0160jdu.UketukeBangouUketukeSyoruiKiziZikenDataTeikyouOutDto;
import jp.go.jpo.cls.app.common.sif.dto.sifsa3dba0560jdt.SinpanBangouSinpanTouzisyaKiziZikenDataTeikyouOutDto;
import jp.go.jpo.cls.app.common.sif.dto.sifsa3dba2470xcs.SinpanBangouUketukeSyoruiKiziTeikyouCustomOutDto;
import jp.go.jpo.cls.app.common.sif.dto.sifsy42svc0010krt.Berg0C0CollectFeeInInDto;
import jp.go.jpo.cls.app.common.sif.dto.sifsy42svc0010krt.RyokinchoshuOutdataDto;
import jp.go.jpo.cls.app.common.sif.dto.sifsy42svc0010krt.SinseininDataDto;
import jp.go.jpo.cls.app.common.sif.dto.sifsy42svc0020krt.RyokinhennouOutdataDto;
import jp.go.jpo.cls.app.web.rc.scgrc11030reg.dto.MessageList;
import jp.go.jpo.cls.app.web.rc.scgrc11030reg.dto.RyoukinTyousyuuHennouTaisyouSentakuGamenUketukeSyoruiItiran;
import jp.go.jpo.cls.app.web.rc.scgrc11030reg.dto.SyosiJouhou;
import jp.go.jpo.cls.common.date.ClsDateService;
import jp.go.jpo.cls.common.exception.PgAppComm404Exception;
import jp.go.jpo.cls.common.exception.PgAppComm409Exception;
import jp.go.jpo.cls.common.exception.PgAppCommException;
import jp.go.jpo.cls.common.exception.PgApplicationException;
import jp.go.jpo.cls.common.exception.PgInputCheckException;
import jp.go.jpo.cls.common.exception.PgNotFoundException;
import jp.go.jpo.cls.common.syslink.send.dbaccesskiban.DbAccessKibanService;

import jp.go.jpo.cls.common.syslink.send.gyoumuapplication.GyoumuApplicationService;
import jp.go.jpo.cls.common.utility.ProcessLogUtils;
import jp.go.jpo.cls.common.utility.SystemInfo;
import jp.go.jpo.cls.domain.MyBatisDao;
import jp.go.jpo.cls.domain.entity.TClsUktkSyrEntity;
import jp.go.jpo.cls.domain.entity.add.SQL_T_CLS_UKTK_SYR_select005Entity;
import jp.go.jpo.cls.domain.param.SQL_T_CLS_UKTK_SYR_select005In;
import lombok.extern.slf4j.Slf4j;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import org.springframework.transaction.annotation.Transactional;

/**
 * 料金徴収返納.
 *
 * @generated
 */
@Service
@Slf4j
public class FncRc11Scg0030Service {

  /**
   * DAO.
   *
   * @generated
   */
  public final MyBatisDao dao;

  /**
   * 書誌情報取得.
   *
   * @generated
   */
  public final CmnBns0070010Service syosiJouhouSyutoku;

  /**
   * DBアクセス基盤サービス.
   *
   * @generated
   */
  public final DbAccessKibanService dbAccessKibanService;

  /**
   * 中間コード情報1件取得.
   *
   * @generated
   */
  public final CmnBns0120010Service tyuukancodeJouhouIkkenSyutoku;

  /**
   * 書類状態(受付書類)推論.
   *
   * @generated
   */
  public final CmnBns0010150Service syoruiJoutaiUketukeSyoruiSuiron;

  /**
   * 業務日付取得.
   *
   * @generated
   */
  public final ClsDateService gyoumuHizukeShutoku;

  /**
   * 類型2A.
   *
   * @generated
   */
  public final GyoumuApplicationService ruikei2A;

  // START UOC

  // END UOC

  /**
   * コンストラクタ.
   *
   * @param dao MyBatisDao
   * @param syosiJouhouSyutoku CmnBns0070010Service
   * @param dbAccessKibanService DbAccessKibanService
   * @param tyuukancodeJouhouIkkenSyutoku CmnBns0120010Service
   * @param syoruiJoutaiUketukeSyoruiSuiron CmnBns0010150Service
   * @param gyoumuHizukeShutoku ClsDateService
   * @param ruikei2A GyoumuApplicationService
   * @customizable
   */
  public FncRc11Scg0030Service(MyBatisDao dao, CmnBns0070010Service syosiJouhouSyutoku,
       DbAccessKibanService dbAccessKibanService, CmnBns0120010Service tyuukancodeJouhouIkkenSyutoku,
       CmnBns0010150Service syoruiJoutaiUketukeSyoruiSuiron, ClsDateService gyoumuHizukeShutoku,
       GyoumuApplicationService ruikei2A) {
    this.dao = dao;
    this.syosiJouhouSyutoku = syosiJouhouSyutoku;
    this.dbAccessKibanService = dbAccessKibanService;
    this.tyuukancodeJouhouIkkenSyutoku = tyuukancodeJouhouIkkenSyutoku;
    this.syoruiJoutaiUketukeSyoruiSuiron = syoruiJoutaiUketukeSyoruiSuiron;
    this.gyoumuHizukeShutoku = gyoumuHizukeShutoku;
    this.ruikei2A = ruikei2A;
    // START UOC

    // END UOC
  }

  /**
   * 料金徴収返納対象書類選択取得.
   *
   * @param indto FncRc11Scg0030ServiceDoSearchIn
   * @return FncRc11Scg0030ServiceDoSearchOut
   * @customizable
   */
  @Transactional
  public FncRc11Scg0030ServiceDoSearchOut doSearch(FncRc11Scg0030ServiceDoSearchIn indto) {
    // START UOC
    // 戻り値 
    FncRc11Scg0030ServiceDoSearchOut fncRc11Scg0030ServiceDoSearchOut = new FncRc11Scg0030ServiceDoSearchOut();
    
    // 戻り値 書誌情報
    SyosiJouhou syosiJouhou = new SyosiJouhou();
    // 戻り値 料金徴収返納対象書類選択画面受付書類一覧
    RyoukinTyousyuuHennouTaisyouSentakuGamenUketukeSyoruiItiran ryoukinTyousyuuHennouTaisyouSentakuGamenUketukeSyoruiItiran = 
            new RyoukinTyousyuuHennouTaisyouSentakuGamenUketukeSyoruiItiran();
    List<RyoukinTyousyuuHennouTaisyouSentakuGamenUketukeSyoruiItiran> ryoukinTyousyuuHennouTaisyouSentakuGamenUketukeSyoruiItiranList =
            new ArrayList<RyoukinTyousyuuHennouTaisyouSentakuGamenUketukeSyoruiItiran>();
    // 戻り値 メッセージリスト
    List<MessageList> messageList = new ArrayList<MessageList>();
    // メッセージ一覧
    MessageList messageItiran = new MessageList();
    // 審判番号＿受付書類記事提供
    List<SinpanBangouUketukeSyoruiKiziTeikyouCustomOutDto> sinpanBangouUketukeSyoruiKiziTeikyouCustomOutDtoList = 
            new ArrayList<SinpanBangouUketukeSyoruiKiziTeikyouCustomOutDto>();
    // 中間記録名
    TyuukanKirokuMeisyouJouhouDto tyuukanKirokuMeisyouJouhouDto = new TyuukanKirokuMeisyouJouhouDto();
    
    try {
      log.debug("2. 書誌情報を取得する。");
      // 書誌情報を取得する
      SyosiJouhouDto syosiJouhouDtoOut = syosiJouhouSyutoku.getSyoshiJouhou(indto.getSinpanBangou(), null, null);
      if (syosiJouhouDtoOut == null) {
        log.debug("3. メッセージ(警告)に#[MSG_S0240_W]を格納してデータが存在しない例外を送出する。");
        ProcessLogUtils.logging(log, indto.getSinpanBangou(), "MSG_L0380_E");
        throw new PgNotFoundException("MSG_S0240_W");
      }
      // 四法区分
      syosiJouhou.setYonpouKubun(syosiJouhouDtoOut.getYonpouKubun());
      // 審判種別
      syosiJouhou.setSinpanSyubetu(syosiJouhouDtoOut.getSinpanSyubetu());
      // 審判番号
      syosiJouhou.setSinpanBangou(syosiJouhouDtoOut.getGenzikenBangou());
      // 出願番号
      syosiJouhou.setSyutuganBangou(syosiJouhouDtoOut.getSyutuganBangou());
      // 登録番号
      syosiJouhou.setTourokuBangou(syosiJouhouDtoOut.getTourokuBangou());
      // 事件状態
      syosiJouhou.setZikenJoutai(syosiJouhouDtoOut.getZikenJoutai());
      // 受付書類名
      syosiJouhou.setUketukeSyoruiMei(syosiJouhouDtoOut.getUketukeSyoruimei());
      // 受付書類番号
      syosiJouhou.setUketukeSyoruiBangou(syosiJouhouDtoOut.getUketukeSyoruiBangou());
      // 受付日
      syosiJouhou.setUketukebi(syosiJouhouDtoOut.getUketukeDate().toString());
      // 書類状態
      syosiJouhou.setSyoruiJoutai(syosiJouhouDtoOut.getSyoruiJouai());
    } catch (PgInputCheckException eInput) {
      log.debug("2-1. 業務例外を送出する。");
      ProcessLogUtils.logging(log, indto.getSinpanBangou(), "MSG_L0420_E");
      throw new PgApplicationException("MSG_L0420_E", eInput);
    } catch (PgApplicationException eApp) {
      log.debug("2-2. 業務例外を送出する。");
      ProcessLogUtils.logging(log, indto.getSinpanBangou(), "MSG_L0410_E");
      throw new PgApplicationException("MSG_L0410_E", eApp);
    }
    try {
      log.debug("4. 受付書類記事を取得する。");
      // 受付書類記事を取得する
      // 業務キーに変換する
      String gyoumukey = "012-" + indto.getSinpanBangou();
      // サービスインタフェースID
      String serviceInterfaceId = "SIF_SA3_DBA2470_XCS";
      // 業務キーリスト
      String[] gyoumuKeyList = new String[1];
      gyoumuKeyList[0] = gyoumukey;
      Map<String, String> uriMapServiceInterfaceIdSifSy3dba2470xcs = new HashMap<String, String>();
      uriMapServiceInterfaceIdSifSy3dba2470xcs.put("ronriSakujoDataKyoyouFlag", "1");
      // XMLデータオブジェクトリスト
      sinpanBangouUketukeSyoruiKiziTeikyouCustomOutDtoList = 
          dbAccessKibanService.customQuery(serviceInterfaceId, gyoumuKeyList, uriMapServiceInterfaceIdSifSy3dba2470xcs, SinpanBangouUketukeSyoruiKiziTeikyouCustomOutDto.class);
      
    } catch (PgAppComm404Exception e404) {
      // TODO: handle exception
      log.debug("4-1. 処理を続行する。");
      ProcessLogUtils.logging(log, indto.getSinpanBangou(), "MSG_L0220_E", e404);
    } catch (PgAppCommException e) {
      // TODO: handle exception
      log.debug("4-2. 業務例外を送出する。");
      ProcessLogUtils.logging(log, indto.getSinpanBangou(), "MSG_L0410_W", e);
      throw new PgApplicationException("MSG_L0410_W");
    }
    
    if (sinpanBangouUketukeSyoruiKiziTeikyouCustomOutDtoList.size() > 0) {
      log.debug("5. 受付書類を取得する。");
      // 受付書類を取得する
      SQL_T_CLS_UKTK_SYR_select005In select005In = new SQL_T_CLS_UKTK_SYR_select005In();
      List<String> uketukeSyoruiBangouList = new ArrayList<String>();
      // 受付書類番号
      uketukeSyoruiBangouList.set(0,
              sinpanBangouUketukeSyoruiKiziTeikyouCustomOutDtoList.get(0)
              .getSinpanBangouUketukeSyoruiKiziTeikyouCustomSinpanBangouUketukeSyoruiKiziTeikyouOutDto()
          .getSinpanBangouUketukeSyoruiKiziTeikyouCustomSinpanBangouUketukeSyoruiKiziOutDto()
          .getSinpanBangouUketukeSyoruiKiziTeikyouCustomUketukeSyoruiKijiOutDto().get(0)
          .getSinpanBangouUketukeSyoruiKiziTeikyouCustomUketukeSyoruiMainOutDto()
              .getSinpanBangouUketukeSyoruiKiziTeikyouCustomUketukeSyoruiOutDto().getUketukeSyoruiBangou());
      select005In.setUketukeSyoruiBangouList(uketukeSyoruiBangouList);
      // 取得件数
      select005In.setLimit(1000);
      // T[受付書類]List #[SQL_T_CLS_UKTK_SYR_select005 | 受付書類_複数検索005]
      List<SQL_T_CLS_UKTK_SYR_select005Entity> sqlTClsUktkSyrSelect005OutList = dao.select(select005In);
      log.debug("5-1. 処理を続行する。");
      if (sqlTClsUktkSyrSelect005OutList.size() > 0) {
        for (int i = 0; i < sqlTClsUktkSyrSelect005OutList.size(); i++) {
          // 中間コード
          String tyuukanCode = sqlTClsUktkSyrSelect005OutList.get(i).getTyknCd();
          try {
            log.debug("6. 中間記録名称情報を取得する。");
            CmnBns0120010Service tyuukancodeJouhouIkkenSyutoku = new CmnBns0120010Service();
            // 中間記録名称情報DTO
            tyuukanKirokuMeisyouJouhouDto =
                tyuukancodeJouhouIkkenSyutoku.getTyuukanKirokuMeisyouJouhou(tyuukanCode);
            if (tyuukanKirokuMeisyouJouhouDto.getTyuukanKirokuMei() == null) {
              // 6.で取得した中間記録名称情報 = nullの場合
              log.debug("6-2. データが存在しない例外を送出する。");
              ProcessLogUtils.loggingWithoutKey(log, indto.getSinpanBangou(), "MSG_L0390_W");
              throw new PgNotFoundException("MSG_L0390_W");
            }
          } catch (PgInputCheckException eInput) {
            log.debug("6-1. 業務例外を送出する。");
            ProcessLogUtils.loggingWithoutKey(log, indto.getSinpanBangou(), "MSG_L0420_W");
            throw new PgInputCheckException("MSG_L0420_W", eInput);
          }
          log.debug("7. 書類状態(受付書類)を取得する。");
          // 書類状態(受付書類)推論呼び出し.invoke
          CmnBns0010150Service syoruiJoutaiUketukeSyoruiSuiron = new CmnBns0010150Service();
          // 処分内容コード
          String SybnNyCd = sqlTClsUktkSyrSelect005OutList.get(i).getSybnNyCd();
          // 方式処分ステータス
          String housikiSyobunStatus = sinpanBangouUketukeSyoruiKiziTeikyouCustomOutDtoList.get(i)
              .getSinpanBangouUketukeSyoruiKiziTeikyouCustomSinpanBangouUketukeSyoruiKiziTeikyouOutDto()
              .getSinpanBangouUketukeSyoruiKiziTeikyouCustomSinpanBangouUketukeSyoruiKiziOutDto()
              .getSinpanBangouUketukeSyoruiKiziTeikyouCustomUketukeSyoruiKijiOutDto().get(0)
              .getSinpanBangouUketukeSyoruiKiziTeikyouCustomUketukeSyoruiMainOutDto()
              .getSinpanBangouUketukeSyoruiKiziTeikyouCustomUketukeSyoruiOutDto().getHousikiSyobunStatus();
          // 指令・却理区分
          String sireiKyakuriKubun = sinpanBangouUketukeSyoruiKiziTeikyouCustomOutDtoList.get(i)
              .getSinpanBangouUketukeSyoruiKiziTeikyouCustomSinpanBangouUketukeSyoruiKiziTeikyouOutDto()
              .getSinpanBangouUketukeSyoruiKiziTeikyouCustomSinpanBangouUketukeSyoruiKiziOutDto()
              .getSinpanBangouUketukeSyoruiKiziTeikyouCustomUketukeSyoruiKijiOutDto().get(0)
              .getSinpanBangouUketukeSyoruiKiziTeikyouCustomUketukeSyoruiMainOutDto()
              .getSinpanBangouUketukeSyoruiKiziTeikyouCustomUketukeSyoruiOutDto().getSireiKyakuriKubun();
          // 書類状態(受付書類)
          String syoruiJoutai = syoruiJoutaiUketukeSyoruiSuiron.getSyoruiJoutaiUketukeSyorui(SybnNyCd,
              housikiSyobunStatus, sireiKyakuriKubun);
          if (syoruiJoutai == null) {
            // 7.で取得した書類状態(受付書類) = nullの場合
            log.debug("7-1. データが存在しない例外を送出する。");
            ProcessLogUtils.loggingWithoutKey(log, indto.getSinpanBangou(), "MSG_L0390_W");
            throw new PgNotFoundException("MSG_L0390_W");
          }
          log.debug("8. 戻り値に設定する料金徴収返納対象書類選択画面受付書類一覧を編集する。");
          // 中間コード
          ryoukinTyousyuuHennouTaisyouSentakuGamenUketukeSyoruiItiran.setTyuukanCode(sqlTClsUktkSyrSelect005OutList.get(i).getTyknCd());
          // 中間記録名
          ryoukinTyousyuuHennouTaisyouSentakuGamenUketukeSyoruiItiran.setTyuukanKirokuMei(tyuukanKirokuMeisyouJouhouDto.getTyuukanKirokuMei());
          // 書類受付日
          ryoukinTyousyuuHennouTaisyouSentakuGamenUketukeSyoruiItiran.setSyoruiUketukebi(sqlTClsUktkSyrSelect005OutList.get(i).getSyrUktkb().toString());
          // 差出元種別
          ryoukinTyousyuuHennouTaisyouSentakuGamenUketukeSyoruiItiran.setSasidasimotoSyubetu(sinpanBangouUketukeSyoruiKiziTeikyouCustomOutDtoList.get(0)
                  .getSinpanBangouUketukeSyoruiKiziTeikyouCustomSinpanBangouUketukeSyoruiKiziTeikyouOutDto()
                  .getSinpanBangouUketukeSyoruiKiziTeikyouCustomSinpanBangouUketukeSyoruiKiziOutDto()
                  .getSinpanBangouUketukeSyoruiKiziTeikyouCustomUketukeSyoruiKijiOutDto().get(0)
                  .getSinpanBangouUketukeSyoruiKiziTeikyouCustomUketukeSyoruiMainOutDto()
                  .getSinpanBangouUketukeSyoruiKiziTeikyouCustomUketukeSyoruiOutDto().getSasidasimotoSyubetu());
          // 異議当事者番号
          ryoukinTyousyuuHennouTaisyouSentakuGamenUketukeSyoruiItiran.setIgiTouzisyaBangou(sinpanBangouUketukeSyoruiKiziTeikyouCustomOutDtoList.get(0)
                  .getSinpanBangouUketukeSyoruiKiziTeikyouCustomSinpanBangouUketukeSyoruiKiziTeikyouOutDto()
                  .getSinpanBangouUketukeSyoruiKiziTeikyouCustomSinpanBangouUketukeSyoruiKiziOutDto()
                  .getSinpanBangouUketukeSyoruiKiziTeikyouCustomUketukeSyoruiKijiOutDto().get(0)
                  .getSinpanBangouUketukeSyoruiKiziTeikyouCustomUketukeSyoruiMainOutDto()
                  .getSinpanBangouUketukeSyoruiKiziTeikyouCustomUketukeSyoruiOutDto().getIgiTouzisyaBangou());
          // 受付形態
          ryoukinTyousyuuHennouTaisyouSentakuGamenUketukeSyoruiItiran.setUketukeKeitai(sqlTClsUktkSyrSelect005OutList.get(i).getUktkKiti());
          // 納付方法コード
          ryoukinTyousyuuHennouTaisyouSentakuGamenUketukeSyoruiItiran.setNouhuHouhouCode(sqlTClsUktkSyrSelect005OutList.get(i).getNhHhCd());
          // 料金徴収額
          ryoukinTyousyuuHennouTaisyouSentakuGamenUketukeSyoruiItiran.setRyoukinTyousyuuGaku(sinpanBangouUketukeSyoruiKiziTeikyouCustomOutDtoList.get(0)
                  .getSinpanBangouUketukeSyoruiKiziTeikyouCustomSinpanBangouUketukeSyoruiKiziTeikyouOutDto()
                  .getSinpanBangouUketukeSyoruiKiziTeikyouCustomSinpanBangouUketukeSyoruiKiziOutDto()
                  .getSinpanBangouUketukeSyoruiKiziTeikyouCustomUketukeSyoruiKijiOutDto().get(0)
                  .getSinpanBangouUketukeSyoruiKiziTeikyouCustomUketukeSyoruiMainOutDto()
                  .getSinpanBangouUketukeSyoruiKiziTeikyouCustomUketukeSyoruiOutDto().getRyoukinTyousyuuGaku().toString());
          // 書類状態
          ryoukinTyousyuuHennouTaisyouSentakuGamenUketukeSyoruiItiran.setSyoruiJoutai(syoruiJoutai);
          // 保留フラグ
          ryoukinTyousyuuHennouTaisyouSentakuGamenUketukeSyoruiItiran.setHoryuuFlg(sqlTClsUktkSyrSelect005OutList.get(i).getHryuFlg());
          // 受付書類番号
          ryoukinTyousyuuHennouTaisyouSentakuGamenUketukeSyoruiItiran.setUketukeSyoruiBangou(sinpanBangouUketukeSyoruiKiziTeikyouCustomOutDtoList.get(0)
                  .getSinpanBangouUketukeSyoruiKiziTeikyouCustomSinpanBangouUketukeSyoruiKiziTeikyouOutDto()
                  .getSinpanBangouUketukeSyoruiKiziTeikyouCustomSinpanBangouUketukeSyoruiKiziOutDto()
                  .getSinpanBangouUketukeSyoruiKiziTeikyouCustomUketukeSyoruiKijiOutDto().get(0)
                  .getSinpanBangouUketukeSyoruiKiziTeikyouCustomUketukeSyoruiMainOutDto()
                  .getSinpanBangouUketukeSyoruiKiziTeikyouCustomUketukeSyoruiOutDto().getUketukeSyoruiBangou());
          
          ryoukinTyousyuuHennouTaisyouSentakuGamenUketukeSyoruiItiranList.add(i, ryoukinTyousyuuHennouTaisyouSentakuGamenUketukeSyoruiItiran);
          }
      }
      
    }
    if (sinpanBangouUketukeSyoruiKiziTeikyouCustomOutDtoList.size() > 1000) {
      log.debug("9. メッセージ(警告)に#[MSG_S1820_W]を格納する。");
      // 上限越えの場合にメッセージを設定する
      // メッセージID
      messageItiran.setMessageId("MSG_S1820_W");
      // 埋め字
      messageItiran.setUmeji(null);
      // メッセージ区分
      messageItiran.setMessageKubun("WARN");
      // 表示区分
      messageItiran.setHyoujiKubun("2");
      messageList.add(messageItiran);
    } else {
      messageList = null;
    }
    
    // 戻り値の設定
    // 書誌情報
    fncRc11Scg0030ServiceDoSearchOut.setSyosiJouhou(syosiJouhou);
    // 料金徴収返納対象書類選択画面受付書類一覧
    if (sinpanBangouUketukeSyoruiKiziTeikyouCustomOutDtoList.size() > 0) {
      fncRc11Scg0030ServiceDoSearchOut.setRyoukinTyousyuuHennouTaisyouSentakuGamenUketukeSyoruiItiran(ryoukinTyousyuuHennouTaisyouSentakuGamenUketukeSyoruiItiranList);
   } else {
      fncRc11Scg0030ServiceDoSearchOut.setRyoukinTyousyuuHennouTaisyouSentakuGamenUketukeSyoruiItiran(null);
    }
    // メッセージリスト
    fncRc11Scg0030ServiceDoSearchOut.setMessageList(messageList);
    
    return fncRc11Scg0030ServiceDoSearchOut;
    // END UOC
  }

  /**
   * 料金徴収返納予納表示.
   *
   * @param indto FncRc11Scg0030ServiceDoHyojiIn
   * @return FncRc11Scg0030ServiceDoHyojiOut
   * @customizable
   */
  @Transactional
  public FncRc11Scg0030ServiceDoHyojiOut doHyoji(FncRc11Scg0030ServiceDoHyojiIn indto) {
    // START UOC
    // 戻り値 FncRc11Scg0030ServiceDoHyojiOut
    FncRc11Scg0030ServiceDoHyojiOut fncRc11Scg0030ServiceDoHyojiOut = 
        new FncRc11Scg0030ServiceDoHyojiOut();
    // 戻り値 書誌情報
    SyosiJouhou syosiJouhou = new SyosiJouhou();
    // 戻り値 受付書類記事
    List<UketukeBangouUketukeSyoruiKiziZikenDataTeikyouOutDto> uketukeBangouUketukeSyoruiKiziZikenDataTeikyouOutDtoList = null;
    log.debug("2. 受付書類を取得する。");
    // 受付書類を取得する。
    TClsUktkSyrEntity tClsUktkSyrEntityIn = new TClsUktkSyrEntity();
    // 受付書類番号
    tClsUktkSyrEntityIn.setUktkSyrBngu(indto.getUketukeSyoruiBangou());
    TClsUktkSyrEntity tClsUktkSyrEntityOut = this.dao.selectByPK(tClsUktkSyrEntityIn);
    
    if (tClsUktkSyrEntityOut == null) {
      log.debug("2-1. データが存在しない例外を送出する。");
      ProcessLogUtils.logging(log, indto.getUketukeSyoruiBangou(), "MSG_L0390_W");
      throw new PgNotFoundException("MSG_L0390_W");
    }
    
    try {
      log.debug("3. 書誌情報を取得する。");
      // 書誌情報を取得する
      SyosiJouhouDto syosiJouhouDtoOut = 
                syosiJouhouSyutoku.getSyoshiJouhou(tClsUktkSyrEntityOut.getTktSmSnpnBngu(), 
                        tClsUktkSyrEntityOut.getTyknCd(), indto.getUketukeSyoruiBangou());
      if (syosiJouhouDtoOut == null) {
        log.debug("3-3. データが存在しない例外を送出する。");
        ProcessLogUtils.logging(log, tClsUktkSyrEntityOut.getTktSmSnpnBngu(), "MSG_L0390_W");
        throw new PgNotFoundException("MSG_L0390_W");
      }
      // 四法区分
      syosiJouhou.setYonpouKubun(syosiJouhouDtoOut.getYonpouKubun());
      // 審判種別
      syosiJouhou.setSinpanSyubetu(syosiJouhouDtoOut.getSinpanSyubetu());
      // 審判番号
      syosiJouhou.setSinpanBangou(syosiJouhouDtoOut.getGenzikenBangou());
      // 出願番号
      syosiJouhou.setSyutuganBangou(syosiJouhouDtoOut.getSyutuganBangou());
      // 登録番号
      syosiJouhou.setTourokuBangou(syosiJouhouDtoOut.getTourokuBangou());
      // 事件状態
      syosiJouhou.setZikenJoutai(syosiJouhouDtoOut.getZikenJoutai());
      // 受付書類名
      syosiJouhou.setUketukeSyoruiMei(syosiJouhouDtoOut.getUketukeSyoruimei());
      // 受付書類番号
      syosiJouhou.setUketukeSyoruiBangou(syosiJouhouDtoOut.getUketukeSyoruiBangou());
      // 受付日
      syosiJouhou.setUketukebi(syosiJouhouDtoOut.getUketukeDate().toString());
      // 書類状態
      syosiJouhou.setSyoruiJoutai(syosiJouhouDtoOut.getSyoruiJouai());
      
    } catch (PgInputCheckException eInput) {
      log.debug("3-1. 業務例外を送出する。");
      ProcessLogUtils.logging(log, tClsUktkSyrEntityOut.getTktSmSnpnBngu(), "MSG_L0420_W");
      throw new PgApplicationException("MSG_L0420_W", eInput);
    } catch (PgApplicationException eApp) {
      log.debug("3-2. 業務例外を送出する。");
      ProcessLogUtils.logging(log, tClsUktkSyrEntityOut.getTktSmSnpnBngu(), "MSG_L0410_W");
      throw new PgApplicationException("MSG_L0410_W", eApp);
    }
    try {
      log.debug("4. 受付書類記事を取得する。");
      // 受付書類記事を取得する
      // 業務キーに変換する
      String gyoumukey = "012-" + indto.getUketukeSyoruiBangou();
      // サービスインタフェースID
      String serviceInterfaceId = "SIF_SA3_DBA0160_JDT";
      // 業務キーリスト
      String[] gyoumuKeyList = new String[1];
      gyoumuKeyList[0] = gyoumukey;
      // XMLデータオブジェクトリスト
      uketukeBangouUketukeSyoruiKiziZikenDataTeikyouOutDtoList = 
          dbAccessKibanService.zikenDataTeikyou(serviceInterfaceId, gyoumuKeyList, 
                UketukeBangouUketukeSyoruiKiziZikenDataTeikyouOutDto.class);
      
    } catch (PgAppComm404Exception e404) {
      // TODO: handle exception
      log.debug("4-1. データが存在しない例外を送出する。");
      ProcessLogUtils.logging(log, indto.getUketukeSyoruiBangou(), "MSG_L0390_W");
      throw new PgNotFoundException("MSG_L0390_W", e404);
    } catch (PgAppCommException e) {
      // TODO: handle exception
      log.debug("4-2. 業務例外を送出する。");
      ProcessLogUtils.logging(log, indto.getUketukeSyoruiBangou(), "MSG_L0410_W");
      throw new PgApplicationException("MSG_L0410_W", e);
    }
    
    log.debug("5. 戻り値に設定する項目を編集する。");
    // 戻り値の設定
    // 書誌情報
    fncRc11Scg0030ServiceDoHyojiOut.setSyosiJouhou(syosiJouhou);
    // 納付方法コード
    fncRc11Scg0030ServiceDoHyojiOut.setNouhuHouhouCode(tClsUktkSyrEntityOut.getNhHhCd());
    // 料金徴収額
    fncRc11Scg0030ServiceDoHyojiOut.setRyoukinTyousyuuGaku(uketukeBangouUketukeSyoruiKiziZikenDataTeikyouOutDtoList
            .get(0).getUketukeBangouUketukeSyoruiKiziZikenData().get(0).getUketukeBangouUketukeSyoruiKiziZikenData()
            .getUketukeSyoruiKizi().getUketukeSyoruiKiziMain().getRyoukinTyousyuugaku().toString());
    // 確定識別番号
    fncRc11Scg0030ServiceDoHyojiOut.setKakuteiSikibetuBangou(uketukeBangouUketukeSyoruiKiziZikenDataTeikyouOutDtoList
            .get(0).getUketukeBangouUketukeSyoruiKiziZikenData().get(0).getUketukeBangouUketukeSyoruiKiziZikenData()
            .getUketukeSyoruiKizi().getUketukeSyoruiKiziMain().getKakuteiSikibetuBangou());
    // 予納台帳番号
    fncRc11Scg0030ServiceDoHyojiOut.setYonouDaityouBangou(tClsUktkSyrEntityOut.getYnuDtyBngu());
    // 中間コード
    fncRc11Scg0030ServiceDoHyojiOut.setTyuukanCode(tClsUktkSyrEntityOut.getTyknCd());
    // 受付書類履歴番号
    fncRc11Scg0030ServiceDoHyojiOut.setUketukeSyoruiRirekiBangou(tClsUktkSyrEntityOut.getRrkBngu());
    // 受付書類記事履歴番号
    fncRc11Scg0030ServiceDoHyojiOut.setUketukeSyoruiKiziRirekiBangou(uketukeBangouUketukeSyoruiKiziZikenDataTeikyouOutDtoList
            .get(0).getUketukeBangouUketukeSyoruiKiziZikenData().get(0).getUketukeBangouUketukeSyoruiKiziZikenData()
            .getUketukeSyoruiKizi().getUketukeSyoruiKiziMain().getRirekiBangou());    
    
    // 戻り値を返す
    return fncRc11Scg0030ServiceDoHyojiOut;
    // END UOC
  }

  /**
   * 料金徴収返納予納更新.
   *
   * @param indto FncRc11Scg0030ServiceDoUpdateIn
   * @return FncRc11Scg0030ServiceDoUpdateOut
   * @customizable
   */
  @Transactional
  public FncRc11Scg0030ServiceDoUpdateOut doUpdate(FncRc11Scg0030ServiceDoUpdateIn indto) {
    // START UOC
    // 戻り値 受付書類記事
    List<UketukeBangouUketukeSyoruiKiziZikenDataTeikyouOutDto> uketukeBangouUketukeSyoruiKiziZikenDataTeikyouOutDtoList =
        new ArrayList<UketukeBangouUketukeSyoruiKiziZikenDataTeikyouOutDto>();
    
    // 戻り値 審判当事者記事
    List<SinpanBangouSinpanTouzisyaKiziZikenDataTeikyouOutDto> sinpanBangouSinpanTouzisyaKiziZikenDataTeikyouOutDtoList =
        new ArrayList<SinpanBangouSinpanTouzisyaKiziZikenDataTeikyouOutDto>();
    
    
    SystemInfo systemInfo = new SystemInfo();
    
    // 入力値
    Berg0C0CollectFeeInInDto berg0C0CollectFeeInInDto = new Berg0C0CollectFeeInInDto();
    // 入力値 申請人データ
    List<SinseininDataDto> sinseininDataDtoList = new ArrayList<SinseininDataDto>();
    SinseininDataDto sinseininDataDto = new SinseininDataDto();
    
    // 戻り値 料金徴収データ
    RyokinchoshuOutdataDto ryokinchoshuOutdataDto = new RyokinchoshuOutdataDto();
    
    // 戻り値 料金返納データ
    RyokinhennouOutdataDto ryokinhennouOutdataDto = new RyokinhennouOutdataDto();
    
    log.debug("2. 業務日付を取得する。");
    // 業務日付を取得する。
    String gyoumuDate = this.gyoumuHizukeShutoku.getGyoumuDate().toString();
    
    log.debug("3. 受付書類を取得する。");
    // 受付書類を取得する。
    TClsUktkSyrEntity tClsUktkSyrEntityIn = new TClsUktkSyrEntity();
    // 受付書類番号
    tClsUktkSyrEntityIn.setUktkSyrBngu(indto.getUketukeSyoruiBangou());
    TClsUktkSyrEntity tClsUktkSyrEntityOut = this.dao.selectByPK(tClsUktkSyrEntityIn);
    
    if (tClsUktkSyrEntityOut == null) {
      log.debug("3-1. データが存在しない例外を送出する。");
      ProcessLogUtils.logging(log, indto.getUketukeSyoruiBangou(), "MSG_L0390_W");
      throw new PgNotFoundException("MSG_L0390_W");
    }
    log.debug("4. 受付書類記事を取得する。");
    // 受付書類記事を取得する
    // 業務キーに変換する
    String gyoumukey = "012-" + indto.getUketukeSyoruiBangou();
    // サービスインタフェースID
    String serviceInterfaceIdSifSa3Dba0160Jdt = "SIF_SA3_DBA0160_JDT";
    // 業務キーリスト
    String[] gyoumuKeyList = new String[1];
    gyoumuKeyList[0] = gyoumukey;
    try {
      // XMLデータオブジェクトリスト
      uketukeBangouUketukeSyoruiKiziZikenDataTeikyouOutDtoList = 
          dbAccessKibanService.zikenDataTeikyou(serviceInterfaceIdSifSa3Dba0160Jdt, gyoumuKeyList, 
              UketukeBangouUketukeSyoruiKiziZikenDataTeikyouOutDto.class);
    } catch (PgAppComm404Exception e404) {
      log.debug("4-1. データが存在しない例外を送出する。");
      ProcessLogUtils.logging(log, indto.getUketukeSyoruiBangou(), "MSG_L0390_W");
      throw new PgApplicationException("MSG_L0390_W", e404);
    } catch (PgAppCommException e) {
      log.debug("4-2. 業務例外を送出する。");
      ProcessLogUtils.logging(log, indto.getUketukeSyoruiBangou(), "MSG_L0410_W");
      throw new PgApplicationException("MSG_L0410_W", e);
    }
    
    log.debug("5. 審判当事者記事を取得する。");
    // 審判当事者記事を取得する。
    // サービスインタフェースID
    String serviceInterfaceIdSifSa3Dba0560Jdt = "SIF_SA3_DBA0560_JDT";
    try {
      sinpanBangouSinpanTouzisyaKiziZikenDataTeikyouOutDtoList = 
          dbAccessKibanService.zikenDataTeikyou(serviceInterfaceIdSifSa3Dba0560Jdt, gyoumuKeyList, 
              SinpanBangouSinpanTouzisyaKiziZikenDataTeikyouOutDto.class);
    } catch (PgAppComm404Exception e404) {
      log.debug("5-1. データが存在しない例外を送出する。");
      ProcessLogUtils.logging(log, indto.getUketukeSyoruiBangou(), "MSG_L0390_W");
      throw new PgApplicationException("MSG_L0390_W", e404);
    } catch (PgAppCommException e) {
      log.debug("5-2. 業務例外を送出する。");
      ProcessLogUtils.logging(log, indto.getUketukeSyoruiBangou(), "MSG_L0410_W");
      throw new PgApplicationException("MSG_L0410_W", e);
    }
    
    if (Cde1300.TYOUSYUU.getCode().equals(indto.getTyousyuuHennou())) {
      // パラメータ.徴収／返納 = 徴収 の場合
      if (uketukeBangouUketukeSyoruiKiziZikenDataTeikyouOutDtoList.get(0)
          .getUketukeBangouUketukeSyoruiKiziZikenData()
          .get(0).getUketukeBangouUketukeSyoruiKiziZikenData().getUketukeSyoruiKizi()
          .getUketukeSyoruiKiziMain().getKakuteiSikibetuBangou().isEmpty()
              || uketukeBangouUketukeSyoruiKiziZikenDataTeikyouOutDtoList.get(0)
                 .getUketukeBangouUketukeSyoruiKiziZikenData().get(0)
                 .getUketukeBangouUketukeSyoruiKiziZikenData().getUketukeSyoruiKizi()
                 .getUketukeSyoruiKiziMain().getKakuteiSikibetuBangou() == null) {
        // 確定識別番号が取得できない場合
        for (int i = 0; i < sinpanBangouSinpanTouzisyaKiziZikenDataTeikyouOutDtoList.get(0)
            .getSinpanBangouSinpanTouzisyaKiziZikenDataDto().getSinpanTouzisyaKiziDto().get(0)
            .getSinpanTouzisyaKiziSubDto().getSinpanTouzisyaDto()
            .getSinpanTouzisyaKurikaesiKoumokuDto().size() || i < 100; i++) {
          
          // 判定条件#1用フラグ
          boolean hanteiFlg1 = false;
          
          if ("1".equals(indto.getHonninKakuninAtoNoTyousyuu())) {
            // 本人確認後の徴収にチェックありの場合
            if (Cde0610.CLAIMANT.getCode().equals(sinpanBangouSinpanTouzisyaKiziZikenDataTeikyouOutDtoList.get(0)
                    .getSinpanBangouSinpanTouzisyaKiziZikenDataDto().getSinpanTouzisyaKiziDto().get(0)
                    .getSinpanTouzisyaKiziSubDto().getSinpanTouzisyaDto()
                    .getSinpanTouzisyaKurikaesiKoumokuDto().get(i).getTouzisyaSyubetu())
                || Cde0610.CLAIMANT_ATTORNEY.getCode().equals(sinpanBangouSinpanTouzisyaKiziZikenDataTeikyouOutDtoList.get(0)
                      .getSinpanBangouSinpanTouzisyaKiziZikenDataDto().getSinpanTouzisyaKiziDto().get(0)
                      .getSinpanTouzisyaKiziSubDto().getSinpanTouzisyaDto()
                      .getSinpanTouzisyaKurikaesiKoumokuDto().get(i).getTouzisyaSyubetu())) {
              // 審判当事者記事.当事者種別が請求人または請求人代理人の場合
              hanteiFlg1 = true;
            } else {
              // 本人確認後の徴収にチェックなしの場合
              if (indto.getSinseininSikibetuBangou().isEmpty()) {
                // 申請人識別番号に値がない場合
                if (Cde0610.CLAIMANT.getCode().equals(sinpanBangouSinpanTouzisyaKiziZikenDataTeikyouOutDtoList.get(0)
                        .getSinpanBangouSinpanTouzisyaKiziZikenDataDto().getSinpanTouzisyaKiziDto().get(0)
                        .getSinpanTouzisyaKiziSubDto().getSinpanTouzisyaDto()
                        .getSinpanTouzisyaKurikaesiKoumokuDto().get(i).getTouzisyaSyubetu())) {
                  // 審判当事者記事.当事者種別が請求人の場合
                 hanteiFlg1 = true;
                }
              } else {
                // 申請人識別番号に値がある場合
                if (Cde0610.CLAIMANT.getCode().equals(sinpanBangouSinpanTouzisyaKiziZikenDataTeikyouOutDtoList.get(0)
                          .getSinpanBangouSinpanTouzisyaKiziZikenDataDto().getSinpanTouzisyaKiziDto().get(0)
                          .getSinpanTouzisyaKiziSubDto().getSinpanTouzisyaDto()
                          .getSinpanTouzisyaKurikaesiKoumokuDto().get(i).getTouzisyaSyubetu())
                    || Cde0610.CLAIMANT_ATTORNEY.getCode().equals(sinpanBangouSinpanTouzisyaKiziZikenDataTeikyouOutDtoList.get(0)
                            .getSinpanBangouSinpanTouzisyaKiziZikenDataDto().getSinpanTouzisyaKiziDto().get(0)
                            .getSinpanTouzisyaKiziSubDto().getSinpanTouzisyaDto()
                            .getSinpanTouzisyaKurikaesiKoumokuDto().get(i).getTouzisyaSyubetu())) {
                  // 審判当事者記事.当事者種別が請求人または請求人代理人の場合
                  hanteiFlg1 = true;
                }
              }
            }
          }
          if (hanteiFlg1) {
            log.debug("6. 判定条件#1を参照し，結果がTRUEの場合，申請人データ(リスト)に5.で取得した審判当事者記事.サブ.審判当事者.申請人コードを追加する。");
            // 判定条件でTRUEの場合，申請人データ(リスト)に審判当事者.申請人コードを追加する。
            sinseininDataDto.setWlzSinseininCode(Cde0570.RYOUKIN_TYOUSYUU.getCode());
            sinseininDataDto.setWlzSinseininCode(sinpanBangouSinpanTouzisyaKiziZikenDataTeikyouOutDtoList.get(0)
                    .getSinpanBangouSinpanTouzisyaKiziZikenDataDto().getSinpanTouzisyaKiziDto()
                    .get(0).getSinpanTouzisyaKiziSubDto().getSinpanTouzisyaDto()
                    .getSinpanTouzisyaKurikaesiKoumokuDto().get(i).getSinseininCode());
            sinseininDataDtoList.add(sinseininDataDto);
          }
        }
        if (sinseininDataDtoList.size() == 0) {
          // 申請人データ(リスト)にデータが存在しない場合，データが存在しない例外を送出する。
          log.debug("6-1. データが存在しない例外を送出する。");
          ProcessLogUtils.logging(log, indto.getUketukeSyoruiBangou(), "MSG_L0390_W");
          throw new PgNotFoundException("MSG_L0390_W");
        }
        
        // 判定条件#2用フラグ
        boolean hanteiFlag2 = false;
        
        if (indto.getHonninKakuninAtoNoTyousyuu().isEmpty()) {
          if (!(indto.getSinseininSikibetuBangou().isEmpty())) {
            hanteiFlag2 = true;
          }
        }
        
        if (hanteiFlag2) {
          // 申請人識別番号数
          int sinseininSikibetuBangouSu = 0;
          
          for (int i = 0; i < sinseininDataDtoList.size(); i++) {
            if (sinseininDataDtoList.get(i).getWlzSinseininCode()
                    .equals(indto.getSinseininSikibetuBangou())) {
              log.debug("7. 申請人識別番号数をカウントアップ(+1)する。");
              // 申請人識別番号数をカウントアップ
              sinseininSikibetuBangouSu++;
            }
          }
          if (sinseininSikibetuBangouSu == 0) {
            // 申請人識別番号数が0の場合，データが存在しない例外を送出する。
            log.debug("8. メッセージ(エラー)に#[MSG_S1850_E]を格納してデータが存在しない例外を送出する。");
            ProcessLogUtils.logging(log, indto.getUketukeSyoruiBangou(), "MSG_L0390_W");
            throw new PgNotFoundException("MSG_S1850_E");
          }
        }
      } else {
        for (int i = 0; i < sinpanBangouSinpanTouzisyaKiziZikenDataTeikyouOutDtoList.get(0)
                .getSinpanBangouSinpanTouzisyaKiziZikenDataDto().getSinpanTouzisyaKiziDto().get(0)
                .getSinpanTouzisyaKiziSubDto().getSinpanTouzisyaDto()
                .getSinpanTouzisyaKurikaesiKoumokuDto().size() || i < 100; i++) {
          sinseininDataDto.setWlzSinseininCode(Cde0570.RYOUKIN_TYOUSYUU.getCode());
          sinseininDataDto.setWlzSinseininCode(uketukeBangouUketukeSyoruiKiziZikenDataTeikyouOutDtoList.get(0)
                  .getUketukeBangouUketukeSyoruiKiziZikenData()
                  .get(0).getUketukeBangouUketukeSyoruiKiziZikenData().getUketukeSyoruiKizi()
                  .getUketukeSyoruiKiziMain().getKakuteiSikibetuBangou());
          log.debug("9. 4.で取得した確定識別番号を申請人データ(リスト)に追加する。");
          sinseininDataDtoList.add(i, sinseininDataDto);
        }
      }
      
      log.debug("10. 納付日, 確定申請人コード, 料金徴収納付確認額を取得する。");
      // 納付日，確定申請人コード，料金徴収納付確認額を取得する。
      // サービスインタフェースID
      String serviceInterfaceIdSifSy42Svc0010Krt = "SIF_SY42_SVC0010_KRT";
      Map<String, String> uriMapServiceInterfaceIdSifSy42Svc0010Krt = new HashMap<String, String>();
      // 送信元プログラムＩＤ
      uriMapServiceInterfaceIdSifSy42Svc0010Krt.put("soushinmoto_prgid", "FncRc11Scg0030Service");
      // 職員コード → 何を設定する？
      uriMapServiceInterfaceIdSifSy42Svc0010Krt.put("shokuin_id", systemInfo.getUserId());
      // 納付方法区分
      uriMapServiceInterfaceIdSifSy42Svc0010Krt.put("wPZ_nohuhoho_kubun", Cde0460.YONOU.getCode());
      // 支払別番号
      uriMapServiceInterfaceIdSifSy42Svc0010Krt.put("wPZ_siharaibetu_no", String.format("%011d", indto.getYonouDaityouBangou()));
      // 代表者チェック識別
      uriMapServiceInterfaceIdSifSy42Svc0010Krt.put("wPZ_daihyoshacheck_sikibetu", Cde0530.TRUE.getCode());
      // 徴収種別
      uriMapServiceInterfaceIdSifSy42Svc0010Krt.put("wPZ_choshu_shubetu", Cde0540.FALSE.getCode());
      // 差出日
      uriMapServiceInterfaceIdSifSy42Svc0010Krt.put("wPZ_sasidasi_bi", tClsUktkSyrEntityOut.getSyrSsdsb().toString());
      // 受付番号
      uriMapServiceInterfaceIdSifSy42Svc0010Krt.put("wPZ_uketuke_no", indto.getUketukeSyoruiBangou());
      // 会計種別
      uriMapServiceInterfaceIdSifSy42Svc0010Krt.put("wPZ_kaikei_shubetu", Cde0550.TOKUBETU_KAIKEI.getCode());
      // 計算額
      uriMapServiceInterfaceIdSifSy42Svc0010Krt.put("wPZ_keisan_gaku", String.format("%09d", indto.getKabusokuGaku()));
      // 書類分類
      uriMapServiceInterfaceIdSifSy42Svc0010Krt.put("wPZ_shorui_bunrui", tClsUktkSyrEntityOut.getSyrBnriCd());
      // 事件番号種別
      uriMapServiceInterfaceIdSifSy42Svc0010Krt.put("wPZ_jikenbango_shubetu", Cde0560.SINPAN.getCode());
      // 出願番号
      uriMapServiceInterfaceIdSifSy42Svc0010Krt.put("wPZ_shutugan_no", "0000000000");
      // 登録番号
      uriMapServiceInterfaceIdSifSy42Svc0010Krt.put("wPZ_toroku_no", "0000000");
      // 分割番号
      uriMapServiceInterfaceIdSifSy42Svc0010Krt.put("wPZ_bunkatu_no", "                               ");
      // 併合件数
      uriMapServiceInterfaceIdSifSy42Svc0010Krt.put("wPZ_heigo_kensu", "0000");
      // 審判番号
      uriMapServiceInterfaceIdSifSy42Svc0010Krt.put("wPZ_sinpan_no", indto.getSinpanBangou());
      // 国際登録番号
      uriMapServiceInterfaceIdSifSy42Svc0010Krt.put("wPZ_kokusaishutugan_no", "         ");
      // 整理番号
      uriMapServiceInterfaceIdSifSy42Svc0010Krt.put("wPZ_seiri_no", String.format("%010s", tClsUktkSyrEntityOut.getSirBngu()));
      // 自納付分年数
      uriMapServiceInterfaceIdSifSy42Svc0010Krt.put("wPZ_jinohubunnen_su", "  ");
      // 至納付分年数
      uriMapServiceInterfaceIdSifSy42Svc0010Krt.put("wPZ_sinohubunnen_su", "  ");
      // 申請人データ
      for (int i = 0; i < sinseininDataDtoList.size(); i++) {
        // 申請者区分
        uriMapServiceInterfaceIdSifSy42Svc0010Krt.put("wLZ_sinseisha_kubun", sinseininDataDtoList.get(i).getWlzSinseishaKubun());
        // 申請人コード
        uriMapServiceInterfaceIdSifSy42Svc0010Krt.put("wLZ_sinseinin_code", sinseininDataDtoList.get(i).getWlzSinseininCode());
      }
      // 強制徴収識別
      uriMapServiceInterfaceIdSifSy42Svc0010Krt.put("wPZ_kyoseichoshu_sikibetu", Cde0580.TUUJOU.getCode());
      
      try {
        ryokinchoshuOutdataDto = ruikei2A
                .kyoutuuResourceDataTeikyou(serviceInterfaceIdSifSy42Svc0010Krt, uriMapServiceInterfaceIdSifSy42Svc0010Krt, RyokinchoshuOutdataDto.class);
      } catch (PgAppComm404Exception e404) {
        log.debug("10-1. データが存在しない例外を送出する。");
        ProcessLogUtils.logging(log, indto.getUketukeSyoruiBangou(), "MSG_L0390_W");
        throw new PgApplicationException("MSG_L0390_W", e404);
      } catch (PgAppCommException e) {
        log.debug("10-2. 業務例外を送出する。");
        ProcessLogUtils.logging(log, indto.getUketukeSyoruiBangou(), "MSG_L0410_W");
        throw new PgApplicationException("MSG_L0410_W", e);
      }
     
    } else {
      // パラメータ.徴収／返納 = 返納 の場合
      log.debug("11. 処理日, 返納確認額を取得する。");
      // 処理日, 返納確認額を取得する。
      Map<String, String> uriMapserviceInterfaceIdSifSy42Svc0020Krt = new HashMap<String, String>();
      // 送信元プログラムＩＤ
      uriMapserviceInterfaceIdSifSy42Svc0020Krt.put("soushinmoto_prgid", "FncRc11Scg0030Service");
      // 職員コード → 何を設定する？
     uriMapserviceInterfaceIdSifSy42Svc0020Krt.put("shokuin_id", systemInfo.getUserId());
      // 納付方法区分
      uriMapserviceInterfaceIdSifSy42Svc0020Krt.put("wPZ_nohuhoho_kubun", Cde0460.YONOU.getCode());
      // 支払別番号
      uriMapserviceInterfaceIdSifSy42Svc0020Krt.put("wPZ_siharaibetu_no", String.format("%011d", indto.getYonouDaityouBangou()));
      // 受付番号
      uriMapserviceInterfaceIdSifSy42Svc0020Krt.put("wPZ_uketuke_no", indto.getUketukeSyoruiBangou());
      // 処分日
      uriMapserviceInterfaceIdSifSy42Svc0020Krt.put("wPZ_shobun_bi", uketukeBangouUketukeSyoruiKiziZikenDataTeikyouOutDtoList.get(0)
              .getUketukeBangouUketukeSyoruiKiziZikenData()
              .get(0).getUketukeBangouUketukeSyoruiKiziZikenData().getUketukeSyoruiKizi()
              .getUketukeSyoruiKiziMain().getSyoruiSyobunDate());
      // 処分結果マーク
      String syobunKekkaMark = "";
      if (Cde1310.GO_TYOUSYUU.getCode().equals(indto.getTesuuryouTyousyuuHennouRiyuu())) {
        syobunKekkaMark = Cde2210.GO_TYOUSYUU.getCode();
      } else if (Cde1310.KYAKKA.getCode().equals(indto.getTesuuryouTyousyuuHennouRiyuu())) {
        syobunKekkaMark = Cde2210.KYAKKA.getCode();
      } else if (Cde1310.HENREI.getCode().equals(indto.getTesuuryouTyousyuuHennouRiyuu())) {
        syobunKekkaMark = Cde2210.HENREI.getCode();
      } else {
        syobunKekkaMark = Cde2210.KAGONOU.getCode();
      }
      uriMapserviceInterfaceIdSifSy42Svc0020Krt.put("wPZ_shobunkekka_mark", syobunKekkaMark);
      // 返納額
      uriMapserviceInterfaceIdSifSy42Svc0020Krt.put("wPZ_henno_gaku", String.format("%09d", indto.getKabusokuGaku()));
      // 書類分類
      uriMapserviceInterfaceIdSifSy42Svc0020Krt.put("wPZ_shorui_bunrui", tClsUktkSyrEntityOut.getSyrBnriCd());
      // 事件番号種別
      uriMapserviceInterfaceIdSifSy42Svc0020Krt.put("wPZ_jikenbango_shubetu", Cde0560.SINPAN.getCode());
      // 出願番号
      uriMapserviceInterfaceIdSifSy42Svc0020Krt.put("wPZ_shutugan_no", "0000000000");
      // 登録番号
      uriMapserviceInterfaceIdSifSy42Svc0020Krt.put("wPZ_toroku_no", "0000000");
      // 分割番号
      uriMapserviceInterfaceIdSifSy42Svc0020Krt.put("wPZ_bunkatu_no", "                               ");
      // 併合件数
      uriMapserviceInterfaceIdSifSy42Svc0020Krt.put("wPZ_heigo_kensu", "0000");
      // 審判番号
      uriMapserviceInterfaceIdSifSy42Svc0020Krt.put("wPZ_sinpan_no", indto.getSinpanBangou());
      // 国際出願番号
      uriMapserviceInterfaceIdSifSy42Svc0020Krt.put("wPZ_kokusaishutugan_no", "         ");
      // 確定申請人コード
      uriMapserviceInterfaceIdSifSy42Svc0020Krt.put("wPZ_kakuteisinseinin_code", uketukeBangouUketukeSyoruiKiziZikenDataTeikyouOutDtoList.get(0)
              .getUketukeBangouUketukeSyoruiKiziZikenData()
              .get(0).getUketukeBangouUketukeSyoruiKiziZikenData().getUketukeSyoruiKizi()
              .getUketukeSyoruiKiziMain().getKakuteiSikibetuBangou());
      // 整理番号
      uriMapserviceInterfaceIdSifSy42Svc0020Krt.put("wPZ_seiri_no", String.format("%010s", tClsUktkSyrEntityOut.getSirBngu()));
      // サービスインタフェースID
      String serviceInterfaceIdSifSy42Svc0020Krt = "SIF_SY42_SVC0020_KRT";
      try {
        ryokinhennouOutdataDto = ruikei2A.kyoutuuResourceDataTeikyou(serviceInterfaceIdSifSy42Svc0020Krt, uriMapserviceInterfaceIdSifSy42Svc0020Krt, RyokinhennouOutdataDto.class);
      } catch (PgAppComm404Exception e404) {
        // TODO: handle exception
        log.debug("11-1. データが存在しない例外を送出する。");
        ProcessLogUtils.logging(log, indto.getUketukeSyoruiBangou(), "MSG_L0390_W");
        throw new PgApplicationException("MSG_L0390_W", e404);
      } catch (PgAppCommException e) {
        // TODO: handle exception
        log.debug("11-2. 業務例外を送出する。");
        ProcessLogUtils.logging(log, indto.getUketukeSyoruiBangou(), "MSG_L0410_W");
        throw new PgApplicationException("MSG_L0410_W", e);
      }
      log.debug("12. 受付書類を更新する。");
      // 受付書類を更新する。
      TClsUktkSyrEntity tClsUktkSyrEntityUpdateIn = new TClsUktkSyrEntity();
      // 受付書類番号
      tClsUktkSyrEntityUpdateIn.setUktkSyrBngu(indto.getUketukeSyoruiBangou());
      // 予納台帳番号
      tClsUktkSyrEntityUpdateIn.setYnuDtyBngu(indto.getYonouDaityouBangou());
      // 履歴番号
      tClsUktkSyrEntityUpdateIn.setRrkBngu(indto.getUketukeSyoruiRirekiBangou());
      
      if (this.dao.updateByValue(tClsUktkSyrEntityUpdateIn) == 0) {
        log.debug("12-1. データが存在しない例外を送出する。");
        ProcessLogUtils.logging(log, indto.getUketukeSyoruiBangou(), "MSG_L0390_W");
        throw new PgNotFoundException("MSG_L0390_W");
      }
      log.debug("13. 受付書類記事を更新する。");
      // 受付書類記事を更新する
      // サービスインタフェースID
      String serviceInterfaceIdSifSa3Dba0140Jdu = "SIF_SA3_DBA0140_JDU";
      // 業務キー
      String gyoumuKey = "012-" + indto.getUketukeSyoruiBangou();
      // TODO 更新情報を書く
      UketukeBangouUketukeSyoruiKiziZikenDataKousinInDto uketukeSyoruiKiziKousinDto =
                new UketukeBangouUketukeSyoruiKiziZikenDataKousinInDto();
      // 予納台帳番号
      uketukeSyoruiKiziKousinDto.getUketukeBangouUketukeSyoruiKiziZikenData()
          .getUketukeBangouUketukeSyoruiKiziZikenData().getUketukeSyoruiKizi()
          .getUketukeSyoruiKiziMain().setYonouDaityouBangou(indto.getYonouDaityouBangou());
      // 料金徴収額
      if (Cde1300.TYOUSYUU.getCode().equals(indto.getTyousyuuHennou())) {
        // 徴収の場合
        uketukeSyoruiKiziKousinDto.getUketukeBangouUketukeSyoruiKiziZikenData()
            .getUketukeBangouUketukeSyoruiKiziZikenData().getUketukeSyoruiKizi().getUketukeSyoruiKiziMain()
            .setRyoukinTyousyuugaku(Integer.parseInt(ryokinchoshuOutdataDto.getWpzRyknchoshunohukkninGaku()));
      } else {
        // 返納の場合
        uketukeSyoruiKiziKousinDto.getUketukeBangouUketukeSyoruiKiziZikenData()
            .getUketukeBangouUketukeSyoruiKiziZikenData().getUketukeSyoruiKizi().getUketukeSyoruiKiziMain()
            .setRyoukinTyousyuugaku(Integer.parseInt(ryokinhennouOutdataDto.getWpzHennokakuninGaku()));
      }
      // 返納徴収日
      if (Cde1300.TYOUSYUU.getCode().equals(indto.getTyousyuuHennou())) {
        // 徴収の場合
        uketukeSyoruiKiziKousinDto.getUketukeBangouUketukeSyoruiKiziZikenData()
            .getUketukeBangouUketukeSyoruiKiziZikenData().getUketukeSyoruiKizi().getUketukeSyoruiKiziMain()
            .setHennouTyousyuuDate(ryokinchoshuOutdataDto.getWpzNohuBi());
      } else {
        // 返納の場合
        uketukeSyoruiKiziKousinDto.getUketukeBangouUketukeSyoruiKiziZikenData()
            .getUketukeBangouUketukeSyoruiKiziZikenData().getUketukeSyoruiKizi().getUketukeSyoruiKiziMain()
            .setHennouTyousyuuDate(ryokinhennouOutdataDto.getWpzShoriBi());
      }
      // 確定識別番号
      if (Cde1300.TYOUSYUU.getCode().equals(indto.getTyousyuuHennou())) {
        // 徴収の場合
        uketukeSyoruiKiziKousinDto.getUketukeBangouUketukeSyoruiKiziZikenData()
            .getUketukeBangouUketukeSyoruiKiziZikenData().getUketukeSyoruiKizi().getUketukeSyoruiKiziMain()
            .setKakuteiSikibetuBangou(ryokinchoshuOutdataDto.getWpzKakuteisinseininCode());
      }
      // 書類処分日
      if (Cde1300.TYOUSYUU.getCode().equals(indto.getTyousyuuHennou())) {
        // 徴収の場合
        uketukeSyoruiKiziKousinDto.getUketukeBangouUketukeSyoruiKiziZikenData()
            .getUketukeBangouUketukeSyoruiKiziZikenData().getUketukeSyoruiKizi().getUketukeSyoruiKiziMain()
            .setSyoruiSyobunDate(gyoumuDate);
      }
      // 履歴番号
      uketukeSyoruiKiziKousinDto.getUketukeBangouUketukeSyoruiKiziZikenData()
          .getUketukeBangouUketukeSyoruiKiziZikenData().getUketukeSyoruiKizi().getUketukeSyoruiKiziMain()
          .setRirekiBangou(indto.getUketukeSyoruiKiziRirekiBangou());
      
      try {
        dbAccessKibanService.zikenDataKousin(serviceInterfaceIdSifSa3Dba0140Jdu, gyoumuKey, null);
      } catch (PgAppComm404Exception e404) {
        // TODO: handle exception
        log.debug("13-1. データが存在しない例外を送出する。");
        ProcessLogUtils.logging(log, indto.getUketukeSyoruiBangou(), "MSG_L0390_W");
        throw new PgApplicationException("MSG_L0390_W", e404);
      } catch (PgAppComm409Exception e409) {
        // TODO: handle exception
        log.debug("13-2. 業務例外を送出する。");
        ProcessLogUtils.logging(log, indto.getUketukeSyoruiBangou(), "MSG_L0400_W");
        throw new PgApplicationException("MSG_L0400_W", e409);
      } catch (PgAppCommException e) {
        // TODO: handle exception
        log.debug("13-3. 業務例外を送出する。");
        ProcessLogUtils.logging(log, indto.getUketukeSyoruiBangou(), "MSG_L0410_W");
        throw new PgApplicationException("MSG_L0410_W", e);
      }
    }
    
    return null;
    // END UOC
  }

  // START UOC

  // END UOC
}
