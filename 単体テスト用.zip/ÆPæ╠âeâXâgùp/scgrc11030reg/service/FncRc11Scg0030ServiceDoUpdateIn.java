/*******************************************************************************************
 * ALL RIGHTS RESERVED,COPYRIGHT (C) 2025,HITACHI,LTD. LICENSED MATERIAL OF HITACHI,LTD.
 *
 * 特許庁殿 刷新審判システム
 *
 *******************************************************************************************/
// ## AutomaticGeneration

package jp.go.jpo.cls.app.web.rc.scgrc11030reg.service;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * FncRc11Scg0030ServiceDoUpdateInクラス.
 *
 * @generated
 */
@Getter
@Setter
@ToString
public class FncRc11Scg0030ServiceDoUpdateIn implements Serializable {

  /**
   * シリアルバージョンUID.
   *
   * @generated
   */
  private static final long serialVersionUID = 1L;

  /**
   * 審判番号.
   *
   * @generated
   */
  private String sinpanBangou;

  /**
   * 受付書類番号.
   *
   * @generated
   */
  private String uketukeSyoruiBangou;

  /**
   * 徴収/返納.
   *
   * @generated
   */
  private String tyousyuuHennou;

  /**
   * 申請人識別番号.
   *
   * @generated
   */
  private String sinseininSikibetuBangou;

  /**
   * 予納台帳番号.
   *
   * @generated
   */
  private String yonouDaityouBangou;

  /**
   * 書類状態.
   *
   * @generated
   */
  private String syoruiJoutai;

  /**
   * 本人確認後の徴収.
   *
   * @generated
   */
  private String honninKakuninAtoNoTyousyuu;

  /**
   * 過不足額.
   *
   * @generated
   */
  private String kabusokuGaku;

  /**
   * 手数料徴収返納理由.
   *
   * @generated
   */
  private String tesuuryouTyousyuuHennouRiyuu;

  /**
   * 受付書類履歴番号.
   *
   * @generated
   */
  private Integer uketukeSyoruiRirekiBangou;

  /**
   * 受付書類記事履歴番号.
   *
   * @generated
   */
  private Integer uketukeSyoruiKiziRirekiBangou;

}
