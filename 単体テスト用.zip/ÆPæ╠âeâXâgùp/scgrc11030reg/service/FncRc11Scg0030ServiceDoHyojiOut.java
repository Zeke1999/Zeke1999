/*******************************************************************************************
 * ALL RIGHTS RESERVED,COPYRIGHT (C) 2025,HITACHI,LTD. LICENSED MATERIAL OF HITACHI,LTD.
 *
 * 特許庁殿 刷新審判システム
 *
 *******************************************************************************************/
// ## AutomaticGeneration

package jp.go.jpo.cls.app.web.rc.scgrc11030reg.service;

import java.io.Serializable;

import jp.go.jpo.cls.app.web.rc.scgrc11030reg.dto.SyosiJouhou;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * FncRc11Scg0030ServiceDoHyojiOutクラス.
 *
 * @generated
 */
@Getter
@Setter
@ToString
@EqualsAndHashCode
public class FncRc11Scg0030ServiceDoHyojiOut implements Serializable {

  /**
   * シリアルバージョンUID.
   *
   * @generated
   */
  private static final long serialVersionUID = 1L;

  /**
   * 書誌情報.
   *
   * @generated
   */
  private SyosiJouhou syosiJouhou;

  /**
   * 納付方法コード.
   *
   * @generated
   */
  private String nouhuHouhouCode;

  /**
   * 料金徴収額.
   *
   * @generated
   */
  private String ryoukinTyousyuuGaku;

  /**
   * 確定識別番号.
   *
   * @generated
   */
  private String kakuteiSikibetuBangou;

  /**
   * 予納台帳番号.
   *
   * @generated
   */
  private String yonouDaityouBangou;

  /**
   * 中間コード.
   *
   * @generated
   */
  private String tyuukanCode;

  /**
   * 受付書類履歴番号.
   *
   * @generated
   */
  private Integer uketukeSyoruiRirekiBangou;

  /**
   * 受付書類記事履歴番号.
   *
   * @generated
   */
  private Integer uketukeSyoruiKiziRirekiBangou;

}
