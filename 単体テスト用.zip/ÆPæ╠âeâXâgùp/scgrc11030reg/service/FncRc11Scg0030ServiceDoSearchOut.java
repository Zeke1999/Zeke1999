/*******************************************************************************************
 * ALL RIGHTS RESERVED,COPYRIGHT (C) 2025,HITACHI,LTD. LICENSED MATERIAL OF HITACHI,LTD.
 *
 * 特許庁殿 刷新審判システム
 *
 *******************************************************************************************/
// ## AutomaticGeneration

package jp.go.jpo.cls.app.web.rc.scgrc11030reg.service;

import java.io.Serializable;

import java.util.List;

import jp.go.jpo.cls.app.web.rc.scgrc11030reg.dto.MessageList;
import jp.go.jpo.cls.app.web.rc.scgrc11030reg.dto.RyoukinTyousyuuHennouTaisyouSentakuGamenUketukeSyoruiItiran;
import jp.go.jpo.cls.app.web.rc.scgrc11030reg.dto.SyosiJouhou;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * FncRc11Scg0030ServiceDoSearchOutクラス.
 *
 * @generated
 */
@Getter
@Setter
@ToString
@EqualsAndHashCode
public class FncRc11Scg0030ServiceDoSearchOut implements Serializable {

  /**
   * シリアルバージョンUID.
   *
   * @generated
   */
  private static final long serialVersionUID = 1L;

  /**
   * 書誌情報.
   *
   * @generated
   */
  private SyosiJouhou syosiJouhou;

  /**
   * 料金徴収返納対象書類選択画面受付書類一覧.
   *
   * @generated
   */
  private List<RyoukinTyousyuuHennouTaisyouSentakuGamenUketukeSyoruiItiran> ryoukinTyousyuuHennouTaisyouSentakuGamenUketukeSyoruiItiran;

  /**
   * メッセージリスト.
   *
   * @generated
   */
  private List<MessageList> messageList;

}
