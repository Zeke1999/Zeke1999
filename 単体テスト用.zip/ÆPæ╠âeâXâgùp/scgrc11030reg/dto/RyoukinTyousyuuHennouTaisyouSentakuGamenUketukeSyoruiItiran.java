/*******************************************************************************************
 * ALL RIGHTS RESERVED,COPYRIGHT (C) 2025,HITACHI,LTD. LICENSED MATERIAL OF HITACHI,LTD.
 *
 * 特許庁殿 刷新審判システム
 *
 *******************************************************************************************/
// ## AutomaticGeneration

package jp.go.jpo.cls.app.web.rc.scgrc11030reg.dto;

import java.io.Serializable;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * 料金徴収返納対象書類選択画面受付書類一覧.
 *
 * @generated
 */
@Getter
@Setter
@ToString
@EqualsAndHashCode
public class RyoukinTyousyuuHennouTaisyouSentakuGamenUketukeSyoruiItiran implements Serializable {

  /**
   * シリアルバージョンUID.
   *
   * @generated
   */
  private static final long serialVersionUID = 1L;

  /**
   * 中間コード.
   *
   * @generated
   */
  private String tyuukanCode;

  /**
   * 中間記録名.
   *
   * @generated
   */
  private String tyuukanKirokuMei;

  /**
   * 書類受付日.
   *
   * @generated
   */
  private String syoruiUketukebi;

  /**
   * 差出元種別.
   *
   * @generated
   */
  private String sasidasimotoSyubetu;

  /**
   * 異議当事者番号.
   *
   * @generated
   */
  private String igiTouzisyaBangou;

  /**
   * 受付形態.
   *
   * @generated
   */
  private String uketukeKeitai;

  /**
   * 納付方法コード.
   *
   * @generated
   */
  private String nouhuHouhouCode;

  /**
   * 料金徴収額.
   *
   * @generated
   */
  private String ryoukinTyousyuuGaku;

  /**
   * 書類状態.
   *
   * @generated
   */
  private String syoruiJoutai;

  /**
   * 保留フラグ.
   *
   * @generated
   */
  private String horyuuFlg;

  /**
   * 受付書類番号.
   *
   * @generated
   */
  private String uketukeSyoruiBangou;

}
