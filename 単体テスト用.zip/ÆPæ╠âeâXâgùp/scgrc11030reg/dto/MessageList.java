/*******************************************************************************************
 * ALL RIGHTS RESERVED,COPYRIGHT (C) 2025,HITACHI,LTD. LICENSED MATERIAL OF HITACHI,LTD.
 *
 * 特許庁殿 刷新審判システム
 *
 *******************************************************************************************/
// ## AutomaticGeneration

package jp.go.jpo.cls.app.web.rc.scgrc11030reg.dto;

import java.io.Serializable;

import java.util.List;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * メッセージリスト.
 *
 * @generated
 */
@Getter
@Setter
@ToString
@EqualsAndHashCode
public class MessageList implements Serializable {

  /**
   * シリアルバージョンUID.
   *
   * @generated
   */
  private static final long serialVersionUID = 1L;

  /**
   * メッセージID.
   *
   * @generated
   */
  private String messageId;

  /**
   * 埋め字.
   *
   * @generated
   */
  private List<String> umeji;

  /**
   * メッセージ区分.
   *
   * @generated
   */
  private String messageKubun;

  /**
   * 表示区分.
   *
   * @generated
   */
  private String hyoujiKubun;

}
