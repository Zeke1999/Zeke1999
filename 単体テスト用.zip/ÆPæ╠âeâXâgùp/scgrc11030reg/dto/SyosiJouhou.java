/*******************************************************************************************
 * ALL RIGHTS RESERVED,COPYRIGHT (C) 2025,HITACHI,LTD. LICENSED MATERIAL OF HITACHI,LTD.
 *
 * 特許庁殿 刷新審判システム
 *
 *******************************************************************************************/
// ## AutomaticGeneration

package jp.go.jpo.cls.app.web.rc.scgrc11030reg.dto;

import java.io.Serializable;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * 書誌情報.
 *
 * @generated
 */
@Getter
@Setter
@ToString
@EqualsAndHashCode
public class SyosiJouhou implements Serializable {

  /**
   * シリアルバージョンUID.
   *
   * @generated
   */
  private static final long serialVersionUID = 1L;

  /**
   * 四法区分.
   *
   * @generated
   */
  private String yonpouKubun;

  /**
   * 審判種別.
   *
   * @generated
   */
  private String sinpanSyubetu;

  /**
   * 審判番号.
   *
   * @generated
   */
  private String sinpanBangou;

  /**
   * 出願番号.
   *
   * @generated
   */
  private String syutuganBangou;

  /**
   * 登録番号.
   *
   * @generated
   */
  private String tourokuBangou;

  /**
   * 事件状態.
   *
   * @generated
   */
  private String zikenJoutai;

  /**
   * 受付書類名.
   *
   * @generated
   */
  private String uketukeSyoruiMei;

  /**
   * 受付書類番号.
   *
   * @generated
   */
  private String uketukeSyoruiBangou;

  /**
   * 受付日.
   *
   * @generated
   */
  private String uketukebi;

  /**
   * 書類状態.
   *
   * @generated
   */
  private String syoruiJoutai;

}
