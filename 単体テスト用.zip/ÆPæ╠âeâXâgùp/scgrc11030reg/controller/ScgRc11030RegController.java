/*******************************************************************************************
 * ALL RIGHTS RESERVED,COPYRIGHT (C) 2025,HITACHI,LTD. LICENSED MATERIAL OF HITACHI,LTD.
 *
 * 特許庁殿 刷新審判システム
 *
 *******************************************************************************************/
// ## AutomaticGeneration

package jp.go.jpo.cls.app.web.rc.scgrc11030reg.controller;

import org.springframework.context.annotation.Scope;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.validation.annotation.Validated;


import jp.go.jpo.cls.app.web.rc.scgrc11030reg.service.FncRc11Scg0030Service;
import jp.go.jpo.cls.app.web.rc.scgrc11030reg.service.FncRc11Scg0030ServiceDoHyojiIn;
import jp.go.jpo.cls.app.web.rc.scgrc11030reg.service.FncRc11Scg0030ServiceDoHyojiOut;
import jp.go.jpo.cls.app.web.rc.scgrc11030reg.service.FncRc11Scg0030ServiceDoSearchIn;
import jp.go.jpo.cls.app.web.rc.scgrc11030reg.service.FncRc11Scg0030ServiceDoSearchOut;
import jp.go.jpo.cls.app.web.rc.scgrc11030reg.service.FncRc11Scg0030ServiceDoUpdateIn;
import jp.go.jpo.cls.app.web.rc.scgrc11030reg.service.FncRc11Scg0030ServiceDoUpdateOut;

import org.springframework.web.bind.annotation.RequestBody;

/**
 * 料金徴収返納作成更新画面群コントローラ.
 *
 * @generated
 */
@RestController
@Scope("request")
@Validated
@RequestMapping(value = "/scgRc11030Reg")
public class ScgRc11030RegController {

  /**
   * 料金徴収返納.
   *
   * @generated
   */
  private final FncRc11Scg0030Service fncRc11Scg0030Service;

  /**
   * コンストラクタ.
   *
   * @param fncRc11Scg0030Service FncRc11Scg0030Service
   * @generated
   */
  public ScgRc11030RegController(FncRc11Scg0030Service fncRc11Scg0030Service) {
    this.fncRc11Scg0030Service = fncRc11Scg0030Service;
  }

  /**
   * 料金徴収返納対象書類選択取得.
   *
   * @param indto FncRc11Scg0030ServiceDoSearchIn
   * @return FncRc11Scg0030ServiceDoSearchOut
   * @generated
   */
  @RequestMapping(value = "1_0/scnRc11030/doSearch?sinpanBangou=[審判番号]", method = RequestMethod.GET,
      produces = "application/json; charset=UTF-8")
  public FncRc11Scg0030ServiceDoSearchOut doSearch(FncRc11Scg0030ServiceDoSearchIn indto) {
    final FncRc11Scg0030ServiceDoSearchOut returnValue = this.fncRc11Scg0030Service.doSearch(indto);
    return returnValue;
  }

  /**
   * 料金徴収返納予納表示.
   *
   * @param indto FncRc11Scg0030ServiceDoHyojiIn
   * @return FncRc11Scg0030ServiceDoHyojiOut
   * @generated
   */
  @RequestMapping(value = "1_0/scnRc11040/doHyoji?uketukeSyoruiBangou=[受付書類番号]", method = RequestMethod.GET,
      produces = "application/json; charset=UTF-8")
  public FncRc11Scg0030ServiceDoHyojiOut doHyoji(FncRc11Scg0030ServiceDoHyojiIn indto) {
    final FncRc11Scg0030ServiceDoHyojiOut returnValue = this.fncRc11Scg0030Service.doHyoji(indto);
    return returnValue;
  }

  /**
   * 料金徴収返納予納更新.
   *
   * @param indto FncRc11Scg0030ServiceDoUpdateIn
   * @return FncRc11Scg0030ServiceDoUpdateOut
   * @generated
   */
  @RequestMapping(value = "1_0/scnRc11040/doUpdate", method = RequestMethod.POST, consumes = "application/json; charset=UTF-8",
      produces = "application/json; charset=UTF-8")
  public FncRc11Scg0030ServiceDoUpdateOut doUpdate(@RequestBody FncRc11Scg0030ServiceDoUpdateIn indto) {
    final FncRc11Scg0030ServiceDoUpdateOut returnValue = this.fncRc11Scg0030Service.doUpdate(indto);
    return returnValue;
  }

}
